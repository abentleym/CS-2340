.. cmake-module:: ../../Modules/CheckIncludeFileCXX.cmake
